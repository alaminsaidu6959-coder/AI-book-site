# 🌐 Build Your First AI Website (Hausa Step-by-Step Guide)
**By: Al-amin Saidu**

## 🧠 Game da Wannan Shafin
Wannan website ɗin an gina shi ne domin taimaka wa masu son koyon AI a sauƙaƙe — musamman cikin Hausa.

## ⚙️ Yadda ake amfani da shi
1. Buɗe `index.html` a browser
2. Idan kana so ka ɗora shi online:
   - Ɗora project ɗin a GitHub
   - Haɗa da Netlify

## ✨ Marubuci
© 2025 Al-amin Saidu
